import React,{Component} from 'react';
import {Link} from 'react-router-dom';
class Home extends Component{
    state={
        weatherDetails:null,
        error:null
    }
    render()

{
    return(
<div class="form-inline"><h1 class="align-center">Hyderabad</h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div class="form-inline">
  <label for="savedLocations">Change Location</label><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <select  name="savedLocations" id="savedLocations" class='form-control'  placeholder="" aria-describedby="savedLocationsHelp" ref={this.savedLocationRef} onChange={this.update}>
      <option></option>
      <option>Bangalore</option>
      <option>Chennai</option>
      <option>Mysore</option>
      <option>NewDelhi
      </option>
      <option>Hyderabad</option>
      </select>
  <small id="savedLocationsHelp" class="text-muted"></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
 
</div>
</div>
    );
}
}


export default Home;

