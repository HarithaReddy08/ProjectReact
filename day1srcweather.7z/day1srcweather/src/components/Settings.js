import React,{Component} from 'react';

class Settings extends Component {
  //for validation create a state
  state={
    value: {savedLocations:'',
    addNewLocation:'',
    defaultLocation:'',
    changeUnits:''},
    errors:
    {
        savedLocations:[],
        addNewLocation:[],
        defaultLocation:[],
        changeUnits:[]},
    
  };

    savedLocationsRef=React.createRef();
    addNewLocationRef=React.createRef();
    defaultLocationRef=React.createRef();
    changeUnits=React.createRef();
    settings=(ev)=>
    {
        
ev.preventDefault();
    }
    render() {
        return (
         <div>
          
                <h1>SETTINGS</h1>
                <div class="form-inline">
  <label for="savedLocations">Saved Locations</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <select  name="savedLocations" id="savedLocations" class='form-control'  placeholder="" aria-describedby="savedLocationsHelp" ref={this.savedLocationRef} onChange={this.update}>
      <option></option>
      <option>Bangalore</option>
      <option>Chennai</option>
      <option>Mysore</option>
      <option>NewDelhi
      </option>
      <option>Hyderabad</option>
      </select>
  <small id="savedLocationsHelp" class="text-muted"></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <button type="button" class="btn btn-danger" >DELETE</button>
 
</div>
                
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div class="form-inline">
  <label for="title">Add a new Location</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="text" name="title" id="title" class='form-control'  placeholder="" aria-describedby="titleHelp" ref={this.titleRef} onChange={this.update}/>
  <small id="titleHelp" class="text-muted"> </small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <button type="button" class="btn btn-primary" >ADD</button>
 
</div>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<div></div>
<div class="form-inline">
  <label for="defaultLocation">Saved Locations</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <select  name="defaultLocation" id="defaultLocation" class='form-control'  placeholder="" aria-describedby="defaultLocationHelp" ref={this.savedLocationRef} onChange={this.update}>
      <option></option>
      <option>Bangalore</option>
      <option>Chennai</option>
      <option>Mysore</option>
      <option>NewDelhi
      </option>
      <option>Hyderabad</option>
      </select>
  <small id="defaultLocationHelp" class="text-muted"></small>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <button type="button" class="btn btn-primary" >SET</button>
 
</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div></div>
  <div class ="form-group">
<label for="changeUnits">Change Units</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input  type="radio" id="imperial" name="changeUnits" value="imperial"/>  
  <label for="imperial">Imperial</label><br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input  type="radio" id="Metric" name="changeUnits"  value="Metric"/>
  <label for="female">Metric</label>
 



{/* <div class="form-group">
  <label for="changeUnits">your Review</label>
  <textarea type="changeUnits" name="changeUnits" id="changeUnits" class='form-control'  placeholder="" aria-describedby="changeUnitsHelp" ref={this.changeUnitsRef} onChange={this.update}></changeUnitsarea>
  <small id="changeUnitsHelp" class="changeUnits-muted">Please enter your REview</small>
  */}


</div><div></div>
</div>


           
        );
    }
}

export default Settings;