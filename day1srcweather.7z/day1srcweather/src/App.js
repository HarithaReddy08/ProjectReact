import React from 'react';
import Home from './components/Home';
import {Route} from 'react-router-dom';
import Navbar from './components/Navbar';
import Settings from './components/Settings';
function App(props)
{
  return(

  
<div className="container my-4">
  <Navbar/>
           <Route path="/" exact component={Home}/>
           <Route path="/settings" exact component={Settings}/>
</div>
  );
}


export default App;
