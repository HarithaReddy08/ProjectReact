// import axios from 'axios';
// export default class weatherService{
//     static baseUrl='https://openweathermap.org';
    
// static getLocation() {
//     if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition(showPosition);
//     } else { 
//       x.innerHTML = "Geolocation is not supported by this browser.";
//     }
//   }
  
//   static showPosition(position) {
//     x.innerHTML = "Latitude: " + position.coords.latitude + 
//     "<br>Longitude: " + position.coords.longitude;
//   }
//   static getWeatherDetails()
//   {
//         return  axios.get(`${this.baseUrl}/Settings`)
//     .then(function(response)
//     {
// return response.data; 
//     })
//     .catch(function(error){ 
// console.log(error.message);
// throw error;
//     })
// }
// }
